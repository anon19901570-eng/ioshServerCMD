#import "TouchInjector.h"
#import <dlfcn.h>
#import <mach/mach_time.h>
#import "../../Dependencies/IOKit-Headers/hid/IOHIDEvent.h"

// MSHookFunction type definition
typedef void (*MSHookFunctionType)(void *symbol, void *replace, void **result);

// BackBoardServices function pointer
static void (*orig_BKSendHIDEvent)(IOHIDEventRef event) = NULL;

@implementation TouchInjector

+ (instancetype)sharedInstance {
    static TouchInjector *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[TouchInjector alloc] init];
    });
    return instance;
}

- (BOOL)installHook {
    // Try common Substrate paths for rootless/rootful jailbreaks
    const char *substratePaths[] = {
        "/usr/lib/libsubstrate.dylib",
        "/var/jb/usr/lib/libsubstrate.dylib"
    };

    void *substrate = NULL;
    for (size_t i = 0; i < sizeof(substratePaths) / sizeof(substratePaths[0]); i++) {
        substrate = dlopen(substratePaths[i], RTLD_LAZY);
        if (substrate) {
            NSLog(@"[TouchInjector] Loaded Substrate from %s", substratePaths[i]);
            break;
        }
    }

    if (!substrate) {
        NSLog(@"[TouchInjector] Failed to load Substrate from all known paths: %s", dlerror());
        return NO;
    }

    // Get MSHookFunction
    MSHookFunctionType MSHookFunction = (MSHookFunctionType)dlsym(substrate, "MSHookFunction");
    if (!MSHookFunction) {
        NSLog(@"[TouchInjector] Failed to find MSHookFunction: %s", dlerror());
        dlclose(substrate);
        return NO;
    }

    // Load BackBoardServices
    void *bbs = dlopen("/System/Library/PrivateFrameworks/BackBoardServices.framework/BackBoardServices", RTLD_NOW);
    if (!bbs) {
        NSLog(@"[TouchInjector] Failed to load BackBoardServices");
        dlclose(substrate);
        return NO;
    }

    // Find BKSendHIDEvent
    void *BKSendHIDEvent = dlsym(bbs, "BKSendHIDEvent");
    if (!BKSendHIDEvent) {
        NSLog(@"[TouchInjector] Failed to find BKSendHIDEvent");
        dlclose(substrate);
        return NO;
    }

    // Hook it
    MSHookFunction(BKSendHIDEvent, (void *)BKSendHIDEvent, (void **)&orig_BKSendHIDEvent);

    if (!orig_BKSendHIDEvent) {
        NSLog(@"[TouchInjector] Hook failed");
        dlclose(substrate);
        return NO;
    }

    NSLog(@"[TouchInjector] Hook installed successfully");
    return YES;
}

- (void)tapAtPoint:(CGPoint)point duration:(NSTimeInterval)duration {
    if (!orig_BKSendHIDEvent) {
        NSLog(@"[TouchInjector] Hook not installed");
        return;
    }
    
    uint64_t timestamp = mach_absolute_time();
    
    // Touch down
    IOHIDEventRef touchDown = IOHIDEventCreateDigitizerFingerEvent(
        kCFAllocatorDefault,
        timestamp,
        0,  // index
        1,  // identity
        kIOHIDDigitizerEventRange | kIOHIDDigitizerEventTouch | kIOHIDDigitizerEventPosition,
        point.x, point.y, 0.0,
        1.0,  // pressure
        0.0,  // twist
        true  // range
    );
    
    orig_BKSendHIDEvent(touchDown);
    CFRelease(touchDown);
    
    // Hold
    usleep((useconds_t)(duration * 1000000));
    
    // Touch up
    timestamp = mach_absolute_time();
    IOHIDEventRef touchUp = IOHIDEventCreateDigitizerFingerEvent(
        kCFAllocatorDefault,
        timestamp,
        0,
        1,
        kIOHIDDigitizerEventRange | kIOHIDDigitizerEventPosition,
        point.x, point.y, 0.0,
        0.0,  // pressure = 0 (up)
        0.0,
        false  // range = false (up)
    );
    
    orig_BKSendHIDEvent(touchUp);
    CFRelease(touchUp);
    
    NSLog(@"[TouchInjector] Tap at (%.0f, %.0f) duration %.3fs", point.x, point.y, duration);
}

- (void)sendText:(NSString *)text {
    if (!orig_BKSendHIDEvent) {
        NSLog(@"[TouchInjector] Hook not installed");
        return;
    }
    
    // Simple keyboard event mapping (a-z, 0-9, space)
    for (NSUInteger i = 0; i < text.length; i++) {
        unichar c = [text characterAtIndex:i];
        uint32_t usage = 0;
        
        if (c >= 'a' && c <= 'z') {
            usage = 0x04 + (c - 'a');  // HID usage for a-z
        } else if (c >= 'A' && c <= 'Z') {
            usage = 0x04 + (c - 'A');  // HID usage for A-Z (with shift)
        } else if (c >= '0' && c <= '9') {
            usage = 0x1E + (c - '0');  // HID usage for 0-9
        } else if (c == ' ') {
            usage = 0x2C;  // Space
        } else {
            continue;  // Skip unsupported characters
        }
        
        uint64_t timestamp = mach_absolute_time();
        
        // Key down
        IOHIDEventRef keyDown = IOHIDEventCreateKeyboardEvent(
            kCFAllocatorDefault,
            timestamp,
            kHIDPage_KeyboardOrKeypad,
            usage,
            true,  // down
            0      // flags
        );
        orig_BKSendHIDEvent(keyDown);
        CFRelease(keyDown);
        
        usleep(10000);  // 10ms
        
        // Key up
        timestamp = mach_absolute_time();
        IOHIDEventRef keyUp = IOHIDEventCreateKeyboardEvent(
            kCFAllocatorDefault,
            timestamp,
            kHIDPage_KeyboardOrKeypad,
            usage,
            false,  // up
            0
        );
        orig_BKSendHIDEvent(keyUp);
        CFRelease(keyUp);
        
        usleep(10000);  // 10ms between characters
    }
    
    NSLog(@"[TouchInjector] Sent text: %@", text);
}

@end
