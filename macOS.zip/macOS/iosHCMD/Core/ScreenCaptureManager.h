#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

NS_ASSUME_NONNULL_BEGIN

@interface ScreenCaptureManager : NSObject

@property (nonatomic, assign) CGSize targetResolution;
@property (nonatomic, assign) int jpegQuality;

- (instancetype)initWithResolution:(CGSize)resolution quality:(int)quality;
- (NSData *)captureScreenshot;
- (void)updateResolution:(CGSize)newResolution;

@end

NS_ASSUME_NONNULL_END
