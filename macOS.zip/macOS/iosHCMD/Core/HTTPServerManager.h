#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

NS_ASSUME_NONNULL_BEGIN

@interface HTTPServerManager : NSObject

- (instancetype)initWithPort:(NSUInteger)port 
                  resolution:(CGSize)resolution 
                     quality:(int)quality;

- (BOOL)start;
- (void)stop;
- (void)updateResolution:(CGSize)newResolution;
- (void)updateQuality:(int)newQuality;

@property (nonatomic, readonly) BOOL isRunning;
@property (nonatomic, readonly) NSUInteger port;

@end

NS_ASSUME_NONNULL_END
