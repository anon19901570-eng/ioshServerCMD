#import "HTTPServerManager.h"
#import "ScreenCaptureManager.h"
#import "TouchInjector.h"
#import "../../Dependencies/GCDWebServer/Core/GCDWebServer.h"
#import "../../Dependencies/GCDWebServer/Responses/GCDWebServerDataResponse.h"

@implementation HTTPServerManager {
    GCDWebServer *_server;
    ScreenCaptureManager *_captureManager;
    TouchInjector *_touchInjector;
}

- (instancetype)initWithPort:(NSUInteger)port
                  resolution:(CGSize)resolution
                     quality:(int)quality {
    self = [super init];
    if (self) {
        _port = port;
        _isRunning = NO;
        
        // Initialize capture manager
        _captureManager = [[ScreenCaptureManager alloc] initWithResolution:resolution quality:quality];
        if (!_captureManager) {
            NSLog(@"[HTTPServer] Failed to initialize ScreenCaptureManager");
            return nil;
        }
        
        // Initialize touch injector
        _touchInjector = [TouchInjector sharedInstance];
        if (![_touchInjector installHook]) {
            NSLog(@"[HTTPServer] Warning: Touch injection hook failed");
        }
        
        // Setup server
        _server = [[GCDWebServer alloc] init];
        [self setupEndpoints];
    }
    return self;
}

- (void)setupEndpoints {
    // GET /screenshot
    __weak typeof(self) weakSelf = self;
    [_server addDefaultHandlerForMethod:@"GET"
                           requestClass:[GCDWebServerRequest class]
                           processBlock:^GCDWebServerResponse *(GCDWebServerRequest *request) {
        // Create strong reference to avoid race condition
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            NSData *errorData = [@"{\"error\":\"Server unavailable\"}" dataUsingEncoding:NSUTF8StringEncoding];
            return [GCDWebServerDataResponse responseWithData:errorData contentType:@"application/json"];
        }

        if ([request.path isEqualToString:@"/screenshot"]) {
            NSData *jpegData = [strongSelf->_captureManager captureScreenshot];
            if (jpegData) {
                return [GCDWebServerDataResponse responseWithData:jpegData contentType:@"image/jpeg"];
            }
            NSData *errorData = [@"{\"error\":\"Screenshot failed\"}" dataUsingEncoding:NSUTF8StringEncoding];
            return [GCDWebServerDataResponse responseWithData:errorData contentType:@"application/json"];
        }

        // GET /tap?x=100&y=200&duration=0.05
        if ([request.path isEqualToString:@"/tap"]) {
            NSString *xStr = request.query[@"x"];
            NSString *yStr = request.query[@"y"];
            NSString *durationStr = request.query[@"duration"] ?: @"0.05";

            if (!xStr || !yStr) {
                NSData *errorData = [@"{\"error\":\"Missing x or y parameter\"}" dataUsingEncoding:NSUTF8StringEncoding];
                return [GCDWebServerDataResponse responseWithData:errorData contentType:@"application/json"];
            }

            CGFloat x = [xStr floatValue];
            CGFloat y = [yStr floatValue];
            NSTimeInterval duration = [durationStr doubleValue];

            [strongSelf->_touchInjector tapAtPoint:CGPointMake(x, y) duration:duration];

            NSString *response = [NSString stringWithFormat:@"{\"success\":true,\"x\":%.0f,\"y\":%.0f,\"duration\":%.3f}",
                                 x, y, duration];
            NSData *responseData = [response dataUsingEncoding:NSUTF8StringEncoding];
            return [GCDWebServerDataResponse responseWithData:responseData contentType:@"application/json"];
        }

        // GET /sendText?text=hello
        if ([request.path isEqualToString:@"/sendText"]) {
            NSString *text = request.query[@"text"];
            if (!text) {
                NSData *errorData = [@"{\"error\":\"Missing text parameter\"}" dataUsingEncoding:NSUTF8StringEncoding];
                return [GCDWebServerDataResponse responseWithData:errorData contentType:@"application/json"];
            }

            [strongSelf->_touchInjector sendText:text];

            NSString *response = [NSString stringWithFormat:@"{\"success\":true,\"text\":\"%@\"}", text];
            NSData *responseData = [response dataUsingEncoding:NSUTF8StringEncoding];
            return [GCDWebServerDataResponse responseWithData:responseData contentType:@"application/json"];
        }

        // GET /status
        if ([request.path isEqualToString:@"/status"]) {
            CGSize resolution = strongSelf->_captureManager.targetResolution;
            int quality = strongSelf->_captureManager.jpegQuality;

            NSString *response = [NSString stringWithFormat:
                @"{\"running\":true,\"port\":%lu,\"resolution\":{\"width\":%.0f,\"height\":%.0f},\"quality\":%d,\"version\":\"1.0.0\"}",
                (unsigned long)strongSelf.port, resolution.width, resolution.height, quality];
            NSData *responseData = [response dataUsingEncoding:NSUTF8StringEncoding];
            return [GCDWebServerDataResponse responseWithData:responseData contentType:@"application/json"];
        }

        NSData *errorData = [@"{\"error\":\"Unknown endpoint\"}" dataUsingEncoding:NSUTF8StringEncoding];
        return [GCDWebServerDataResponse responseWithData:errorData contentType:@"application/json"];
    }];
}

- (BOOL)start {
    if (_isRunning) {
        NSLog(@"[HTTPServer] Already running");
        return YES;
    }
    
    NSDictionary *options = @{
        GCDWebServerOption_Port: @(_port),
        GCDWebServerOption_BindToLocalhost: @NO,  // Listen on 0.0.0.0
        GCDWebServerOption_AutomaticallySuspendInBackground: @NO
    };
    
    NSError *error = nil;
    if ([_server startWithOptions:options error:&error]) {
        _isRunning = YES;
        NSLog(@"[HTTPServer] Started on port %lu", (unsigned long)_port);
        return YES;
    } else {
        NSLog(@"[HTTPServer] Failed to start: %@", error);
        return NO;
    }
}

- (void)stop {
    if (!_isRunning) {
        return;
    }
    
    [_server stop];
    _isRunning = NO;
    NSLog(@"[HTTPServer] Stopped");
}

- (void)updateResolution:(CGSize)newResolution {
    [_captureManager updateResolution:newResolution];
}

- (void)updateQuality:(int)newQuality {
    _captureManager.jpegQuality = newQuality;
}

@end
