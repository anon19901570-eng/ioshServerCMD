#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

NS_ASSUME_NONNULL_BEGIN

@interface TouchInjector : NSObject

+ (instancetype)sharedInstance;
- (BOOL)installHook;
- (void)tapAtPoint:(CGPoint)point duration:(NSTimeInterval)duration;
- (void)sendText:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
