#import "ScreenCaptureManager.h"
#import <IOKit/IOKitLib.h>
#import <Accelerate/Accelerate.h>
#import <ImageIO/ImageIO.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import <mach/mach_time.h>
#import <dlfcn.h>
#import "../../Dependencies/IOKit-Headers/IOSurface.h"
#import "../../Dependencies/IOKit-Headers/IOMobileFramebuffer.h"

@implementation ScreenCaptureManager {
    IOMobileFramebufferConnection _fbConnection;
    IOSurfaceRef _surface;
    void *_surfaceBaseAddr;
    size_t _nativeWidth;
    size_t _nativeHeight;
    size_t _bytesPerRow;
    
    uint8_t *_scaledBuffer;
    BOOL _surfaceLocked;
}

- (instancetype)initWithResolution:(CGSize)resolution quality:(int)quality {
    self = [super init];
    if (self) {
        _targetResolution = resolution;
        _jpegQuality = quality;
        
        // Load IOMobileFramebuffer dynamically
        void *fwk = dlopen("/System/Library/PrivateFrameworks/IOMobileFramebuffer.framework/IOMobileFramebuffer", RTLD_NOW);
        if (!fwk) {
            NSLog(@"[ScreenCapture] Failed to load IOMobileFramebuffer");
            return nil;
        }
        
        kern_return_t (*Open)(io_service_t, task_port_t, unsigned int, IOMobileFramebufferConnection *);
        Open = dlsym(fwk, "IOMobileFramebufferOpen");
        
        kern_return_t (*GetSurface)(IOMobileFramebufferConnection, int, IOSurfaceRef *);
        GetSurface = dlsym(fwk, "IOMobileFramebufferGetLayerDefaultSurface");
        
        if (!Open || !GetSurface) {
            NSLog(@"[ScreenCapture] Failed to find required symbols");
            return nil;
        }
        
        // Open framebuffer
        // Note: kIOMasterPortDefault is deprecated on iOS, use kIOMainPortDefault or 0
        kern_return_t ret = Open(0, mach_task_self(), 0, &_fbConnection);
        if (ret != KERN_SUCCESS) {
            NSLog(@"[ScreenCapture] IOMobileFramebufferOpen failed: %d", ret);
            return nil;
        }
        
        ret = GetSurface(_fbConnection, 0, &_surface);
        if (ret != KERN_SUCCESS) {
            NSLog(@"[ScreenCapture] GetLayerDefaultSurface failed: %d", ret);
            return nil;
        }
        
        // Lock surface
        ret = IOSurfaceLock(_surface, kIOSurfaceLockReadOnly, NULL);
        if (ret != KERN_SUCCESS) {
            NSLog(@"[ScreenCapture] IOSurfaceLock failed: %d", ret);
            return nil;
        }
        _surfaceLocked = YES;
        
        // Get properties
        _surfaceBaseAddr = IOSurfaceGetBaseAddress(_surface);
        _nativeWidth = IOSurfaceGetWidth(_surface);
        _nativeHeight = IOSurfaceGetHeight(_surface);
        _bytesPerRow = IOSurfaceGetBytesPerRow(_surface);
        
        if (!_surfaceBaseAddr) {
            NSLog(@"[ScreenCapture] Invalid base address");
            return nil;
        }
        
        // Allocate scaled buffer
        size_t scaledSize = (size_t)resolution.width * (size_t)resolution.height * 4;
        _scaledBuffer = malloc(scaledSize);
        
        NSLog(@"[ScreenCapture] Init: %zux%zu → %.0fx%.0f",
              _nativeWidth, _nativeHeight, resolution.width, resolution.height);
    }
    return self;
}

- (NSData *)captureScreenshot {
    @autoreleasepool {
        uint64_t start = mach_absolute_time();
        
        BOOL needsScaling = (_targetResolution.width != _nativeWidth ||
                             _targetResolution.height != _nativeHeight);
        
        uint8_t *sourceBuffer = _surfaceBaseAddr;
        size_t sourceWidth = _nativeWidth;
        size_t sourceHeight = _nativeHeight;
        size_t sourceBytesPerRow = _bytesPerRow;
        
        // Downscale if needed
        if (needsScaling) {
            vImage_Buffer src = {
                .data = _surfaceBaseAddr,
                .height = (vImagePixelCount)_nativeHeight,
                .width = (vImagePixelCount)_nativeWidth,
                .rowBytes = _bytesPerRow
            };
            
            vImage_Buffer dest = {
                .data = _scaledBuffer,
                .height = (vImagePixelCount)_targetResolution.height,
                .width = (vImagePixelCount)_targetResolution.width,
                .rowBytes = (size_t)_targetResolution.width * 4
            };
            
            vImageScale_ARGB8888(&src, &dest, NULL, kvImageNoFlags);
            
            sourceBuffer = _scaledBuffer;
            sourceWidth = (size_t)_targetResolution.width;
            sourceHeight = (size_t)_targetResolution.height;
            sourceBytesPerRow = sourceWidth * 4;
        }
        
        // Create CGImage from buffer
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();

        // Cast to avoid enum type mismatch warning
        CGBitmapInfo bitmapInfo = (CGBitmapInfo)kCGImageAlphaNoneSkipFirst | (CGBitmapInfo)kCGBitmapByteOrder32Little;

        CGContextRef context = CGBitmapContextCreate(
            sourceBuffer,
            sourceWidth,
            sourceHeight,
            8,
            sourceBytesPerRow,
            colorSpace,
            bitmapInfo
        );
        
        CGImageRef image = CGBitmapContextCreateImage(context);
        
        // Encode to JPEG using ImageIO
        NSMutableData *jpegData = [NSMutableData data];
        CGImageDestinationRef dest = CGImageDestinationCreateWithData(
            (__bridge CFMutableDataRef)jpegData,
            (__bridge CFStringRef)UTTypeJPEG.identifier,
            1,
            NULL
        );
        
        NSDictionary *options = @{
            (__bridge id)kCGImageDestinationLossyCompressionQuality: @(_jpegQuality / 100.0)
        };
        
        CGImageDestinationAddImage(dest, image, (__bridge CFDictionaryRef)options);
        CGImageDestinationFinalize(dest);
        
        // Cleanup
        CFRelease(dest);
        CGImageRelease(image);
        CGContextRelease(context);
        CGColorSpaceRelease(colorSpace);
        
        // Performance log
        uint64_t end = mach_absolute_time();
        mach_timebase_info_data_t info;
        mach_timebase_info(&info);
        double ms = (end - start) * info.numer / info.denom / 1e6;
        
        NSLog(@"[ScreenCapture] %.0fx%.0f in %.2fms (%.1f KB)",
              (double)sourceWidth, (double)sourceHeight, ms, jpegData.length / 1024.0);
        
        return jpegData;
    }
}

- (void)updateResolution:(CGSize)newResolution {
    if (CGSizeEqualToSize(_targetResolution, newResolution)) return;
    
    _targetResolution = newResolution;
    
    free(_scaledBuffer);
    size_t scaledSize = (size_t)newResolution.width * (size_t)newResolution.height * 4;
    _scaledBuffer = malloc(scaledSize);
    
    NSLog(@"[ScreenCapture] Resolution updated to %.0fx%.0f", newResolution.width, newResolution.height);
}

- (void)dealloc {
    if (_surfaceLocked) {
        IOSurfaceUnlock(_surface, kIOSurfaceLockReadOnly, NULL);
    }
    free(_scaledBuffer);
}

@end
