import SwiftUI
import Combine

@MainActor
final class ServerViewModel: ObservableObject {
    @Published var isRunning = false
    @Published var port: UInt16 = 5005
    @Published var selectedResolution: ResolutionOption = .half
    @Published var jpegQuality: Int = 60
    
    private var serverManager: HTTPServerManager?
    
    enum ResolutionOption: String, CaseIterable, Identifiable {
        case native = "Native (1334x750)"
        case half = "50% (667x375)"
        case quarter = "25% (334x188)"
        case custom = "Custom"
        
        var id: String { rawValue }
        
        var size: CGSize {
            switch self {
            case .native: return CGSize(width: 1334, height: 750)
            case .half: return CGSize(width: 667, height: 375)
            case .quarter: return CGSize(width: 334, height: 188)
            case .custom: return CGSize(width: 800, height: 600)
            }
        }
    }
    
    func startServer() {
        guard !isRunning else { return }
        
        serverManager = HTTPServerManager(
            port: UInt(port),
            resolution: selectedResolution.size,
            quality: Int32(jpegQuality)
        )
        
        if let manager = serverManager, manager.start() {
            isRunning = true
            NSLog("[ViewModel] Server started on port \(port)")
        } else {
            NSLog("[ViewModel] Failed to start server")
        }
    }
    
    func stopServer() {
        guard isRunning else { return }
        
        serverManager?.stop()
        serverManager = nil
        isRunning = false
        NSLog("[ViewModel] Server stopped")
    }
    
    func updateResolution(_ newResolution: ResolutionOption) {
        selectedResolution = newResolution
        serverManager?.updateResolution(newResolution.size)
        NSLog("[ViewModel] Resolution updated to \(newResolution.rawValue)")
    }
    
    func updateQuality(_ newQuality: Int) {
        jpegQuality = newQuality
        serverManager?.updateQuality(Int32(newQuality))
        NSLog("[ViewModel] Quality updated to \(newQuality)")
    }
}
