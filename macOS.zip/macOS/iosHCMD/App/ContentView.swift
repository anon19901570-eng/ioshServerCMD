import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = ServerViewModel()
    
    var body: some View {
        NavigationView {
            Form {
                // Server Status Section
                Section(header: Text("Server Status")) {
                    HStack {
                        Text("Status")
                        Spacer()
                        Text(viewModel.isRunning ? "Running" : "Stopped")
                            .foregroundColor(viewModel.isRunning ? .green : .red)
                    }
                    
                    Toggle("Server", isOn: Binding(
                        get: { viewModel.isRunning },
                        set: { newValue in
                            if newValue {
                                viewModel.startServer()
                            } else {
                                viewModel.stopServer()
                            }
                        }
                    ))
                }
                
                // Configuration Section
                Section(header: Text("Configuration")) {
                    HStack {
                        Text("Port")
                        Spacer()
                        TextField("Port", value: $viewModel.port, format: .number)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .frame(width: 80)
                            .disabled(viewModel.isRunning)
                    }
                    
                    Picker("Resolution", selection: $viewModel.selectedResolution) {
                        ForEach(ServerViewModel.ResolutionOption.allCases) { option in
                            Text(option.rawValue).tag(option)
                        }
                    }
                    .onChange(of: viewModel.selectedResolution) { newValue in
                        if viewModel.isRunning {
                            viewModel.updateResolution(newValue)
                        }
                    }
                    
                    VStack(alignment: .leading) {
                        HStack {
                            Text("JPEG Quality")
                            Spacer()
                            Text("\(viewModel.jpegQuality)%")
                                .foregroundColor(.secondary)
                        }
                        
                        Slider(value: Binding(
                            get: { Double(viewModel.jpegQuality) },
                            set: { newValue in
                                viewModel.jpegQuality = Int(newValue)
                                if viewModel.isRunning {
                                    viewModel.updateQuality(Int(newValue))
                                }
                            }
                        ), in: 1...100, step: 1)
                    }
                }
                
                // API Endpoints Section
                Section(header: Text("API Endpoints")) {
                    if viewModel.isRunning {
                        VStack(alignment: .leading, spacing: 8) {
                            EndpointRow(method: "GET", path: "/screenshot", description: "Capture screen")
                            EndpointRow(method: "GET", path: "/tap?x=&y=&duration=", description: "Inject tap")
                            EndpointRow(method: "GET", path: "/sendText?text=", description: "Send text")
                            EndpointRow(method: "GET", path: "/status", description: "Server status")
                        }
                        .font(.system(.caption, design: .monospaced))
                    } else {
                        Text("Start server to see endpoints")
                            .foregroundColor(.secondary)
                    }
                }
                
                // Info Section
                Section(header: Text("Information")) {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Target")
                        Spacer()
                        Text("iOS 16.0+")
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle("iosHCMD")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct EndpointRow: View {
    let method: String
    let path: String
    let description: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(method)
                    .foregroundColor(.blue)
                    .bold()
                Text(path)
                    .foregroundColor(.primary)
            }
            Text(description)
                .foregroundColor(.secondary)
                .font(.caption2)
        }
    }
}

#Preview {
    ContentView()
}
