#ifndef IOMOBILEFRAMEBUFFER_H
#define IOMOBILEFRAMEBUFFER_H

#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include "IOSurface.h"

typedef void *IOMobileFramebufferConnection;

kern_return_t IOMobileFramebufferOpen(
    io_service_t service,
    task_port_t owningTask,
    unsigned int type,
    IOMobileFramebufferConnection *connection
);

kern_return_t IOMobileFramebufferGetLayerDefaultSurface(
    IOMobileFramebufferConnection connection,
    int layer,
    IOSurfaceRef *surface
);

#endif
