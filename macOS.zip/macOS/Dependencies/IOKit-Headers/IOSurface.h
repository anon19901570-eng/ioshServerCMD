#ifndef IOSURFACE_PRIVATE_H
#define IOSURFACE_PRIVATE_H

#include <CoreFoundation/CoreFoundation.h>
#include <mach/mach.h>

// Forward declare IOSurfaceRef if not already defined
#ifndef __IOSURFACE__
typedef struct __IOSurface *IOSurfaceRef;
#endif

// Only define these constants if they haven't been defined yet
#ifndef kIOSurfaceLockReadOnly
#define kIOSurfaceLockReadOnly 0x00000001
#endif

#ifndef kIOSurfaceLockAvoidSync
#define kIOSurfaceLockAvoidSync 0x00000002
#endif

// Function declarations (these won't conflict even if declared elsewhere)
kern_return_t IOSurfaceLock(IOSurfaceRef buffer, uint32_t options, uint32_t *seed);
kern_return_t IOSurfaceUnlock(IOSurfaceRef buffer, uint32_t options, uint32_t *seed);
void *IOSurfaceGetBaseAddress(IOSurfaceRef buffer);
size_t IOSurfaceGetWidth(IOSurfaceRef buffer);
size_t IOSurfaceGetHeight(IOSurfaceRef buffer);
size_t IOSurfaceGetBytesPerRow(IOSurfaceRef buffer);

#endif
