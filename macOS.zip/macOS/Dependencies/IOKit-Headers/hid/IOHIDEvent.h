#ifndef IOHIDEVENT_H
#define IOHIDEVENT_H

#include <CoreFoundation/CoreFoundation.h>

typedef struct __IOHIDEvent *IOHIDEventRef;

enum {
    kIOHIDDigitizerEventRange = 1 << 0,
    kIOHIDDigitizerEventTouch = 1 << 1,
    kIOHIDDigitizerEventPosition = 1 << 2
};

enum {
    kHIDPage_KeyboardOrKeypad = 0x07
};

IOHIDEventRef IOHIDEventCreateDigitizerFingerEvent(
    CFAllocatorRef allocator,
    uint64_t timeStamp,
    uint32_t index,
    uint32_t identity,
    uint32_t eventMask,
    double x, double y, double z,
    double pressure,
    double twist,
    Boolean range
);

IOHIDEventRef IOHIDEventCreateKeyboardEvent(
    CFAllocatorRef allocator,
    uint64_t timeStamp,
    uint32_t usagePage,
    uint32_t usage,
    Boolean down,
    uint32_t flags
);

#endif
