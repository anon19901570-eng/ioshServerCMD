#ifndef SUBSTRATE_H_
#define SUBSTRATE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <objc/runtime.h>

// MSHookFunction - Hook a C/C++ function
void MSHookFunction(void *symbol, void *replace, void **result);

// MSHookMessageEx - Hook an Objective-C method
void MSHookMessageEx(Class _class, SEL sel, IMP imp, IMP *result);

#ifdef __cplusplus
}
#endif

#endif /* SUBSTRATE_H_ */
